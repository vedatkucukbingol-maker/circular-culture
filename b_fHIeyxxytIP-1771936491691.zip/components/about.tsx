import { Leaf, Waves, Recycle } from "lucide-react"

const stats = [
  { value: "50+", label: "Hotels Consulted" },
  { value: "35%", label: "Avg Waste Reduction" },
  { value: "20%", label: "Energy Savings" },
  { value: "1200+", label: "Staff Trained" },
]

export function About() {
  return (
    <section id="about" className="py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        {/* Overline */}
        <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent">
          Our Mission
        </p>

        <div className="mt-8 grid gap-12 lg:grid-cols-2 lg:gap-20">
          {/* Left */}
          <div>
            <h2 className="text-balance font-serif text-3xl font-medium leading-snug text-foreground md:text-4xl">
              Dedicated to Sustainability, Culture {'&'} Growth.
            </h2>
            <p className="mt-6 text-pretty leading-relaxed text-muted-foreground">
              Circular Culture is a consultancy rooted in Antalya, working at the intersection of hospitality and environmental stewardship. We help hotels and resorts along the Turkish Riviera transition to circular economy practices — reducing waste, conserving energy, and empowering their teams with sustainability knowledge.
            </p>
            <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
              {'Because when tourism and nature move in sync, the best outcomes don\'t just happen — they flourish.'}
            </p>
          </div>

          {/* Right: Pillars */}
          <div className="flex flex-col gap-6">
            {[
              {
                icon: Recycle,
                title: "Circular Economy",
                desc: "Transforming linear hotel operations into closed-loop systems that minimise waste and maximise resource value.",
              },
              {
                icon: Leaf,
                title: "Ecosystem Thinking",
                desc: "Connecting hotels with local farms, cooperatives, and green suppliers to build resilient regional networks.",
              },
              {
                icon: Waves,
                title: "Mediterranean Heritage",
                desc: "Honouring the cultural and natural heritage of the Turkish Riviera through responsible tourism practices.",
              },
            ].map((item) => (
              <div key={item.title} className="flex gap-4 rounded-xl border border-border bg-card p-5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                  <item.icon className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-card-foreground">{item.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 gap-6 md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="font-serif text-3xl font-semibold text-primary md:text-4xl">
                {stat.value}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
