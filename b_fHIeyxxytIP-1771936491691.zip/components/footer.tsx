'use client'

import { useState, type FormEvent } from "react"
import Link from "next/link"

function NewsletterForm() {
  const [email, setEmail] = useState("")

  function handleNewsletterSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setEmail("")
  }

  return (
    <form className="mt-4 flex gap-2" onSubmit={handleNewsletterSubmit}>
      <input
        type="email"
        placeholder="Enter email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="flex-1 rounded-full border border-primary-foreground/20 bg-primary-foreground/5 px-4 py-2 text-sm text-primary-foreground placeholder:text-primary-foreground/40 focus:border-accent focus:outline-none"
      />
      <button
        type="submit"
        className="rounded-full bg-accent px-5 py-2 text-sm font-medium text-accent-foreground transition-opacity hover:opacity-90"
      >
        Submit
      </button>
    </form>
  )
}

export function Footer() {
  return (
    <footer className="border-t border-border bg-primary py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid gap-10 md:grid-cols-3">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground">
                <span className="font-serif text-xs font-bold text-primary">CC</span>
              </div>
              <span className="text-base font-semibold text-primary-foreground">
                Circular Culture
              </span>
            </div>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-primary-foreground/60">
              Sustainable tourism consultancy helping hotels embrace circular
              economy practices across the Turkish Riviera.
            </p>
          </div>

          {/* Links */}
          <div className="grid grid-cols-2 gap-6">
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-primary-foreground/40">
                Navigation
              </h4>
              <ul className="mt-3 flex flex-col gap-2">
                {["Services", "About", "Contact"].map((item) => (
                  <li key={item}>
                    <Link
                      href={`#${item.toLowerCase()}`}
                      className="text-sm text-primary-foreground/70 transition-colors hover:text-primary-foreground"
                    >
                      {item}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-primary-foreground/40">
                Connect
              </h4>
              <ul className="mt-3 flex flex-col gap-2">
                {["LinkedIn", "Instagram"].map((item) => (
                  <li key={item}>
                    <span className="cursor-pointer text-sm text-primary-foreground/70 transition-colors hover:text-primary-foreground">
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-primary-foreground/40">
              Newsletter
            </h4>
            <p className="mt-3 text-sm text-primary-foreground/60">
              Stay updated on sustainable tourism insights.
            </p>
            <NewsletterForm />
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 flex flex-col items-center justify-between gap-2 border-t border-primary-foreground/10 pt-6 md:flex-row">
          <p className="text-xs text-primary-foreground/40">
            {`\u00A9 ${new Date().getFullYear()} Circular Culture. All rights reserved.`}
          </p>
          <p className="text-xs text-primary-foreground/40">
            {"Dedicated to sustainability, culture & growth."}
          </p>
        </div>
      </div>
    </footer>
  )
}
