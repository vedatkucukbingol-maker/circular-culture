"use client"

import { useState } from "react"
import { Send, MapPin, Mail, Phone } from "lucide-react"

export function Contact() {
  const [submitted, setSubmitted] = useState(false)

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <section id="contact" className="py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        {/* Header */}
        <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent">
          Contact
        </p>
        <h2 className="mt-4 max-w-lg text-balance font-serif text-3xl font-medium leading-snug text-foreground md:text-4xl">
          {"Ready to experience our services? Let's start planning."}
        </h2>

        <div className="mt-14 grid gap-14 lg:grid-cols-5">
          {/* Contact Info */}
          <div className="flex flex-col gap-8 lg:col-span-2">
            <p className="text-pretty leading-relaxed text-muted-foreground">
              Whether you manage a boutique hotel or a large resort, we tailor every engagement to your property. Reach out and we will arrange a discovery call.
            </p>

            <div className="flex flex-col gap-5">
              <div className="flex items-start gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                  <MapPin className="h-4 w-4 text-accent" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Location</p>
                  <p className="text-sm text-muted-foreground">Antalya, Turkey</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                  <Mail className="h-4 w-4 text-accent" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Email</p>
                  <p className="text-sm text-muted-foreground">hello@circularculture.co</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                  <Phone className="h-4 w-4 text-accent" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Phone</p>
                  <p className="text-sm text-muted-foreground">+90 242 000 0000</p>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            {submitted ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-border bg-card p-12 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/10">
                  <Send className="h-6 w-6 text-accent" />
                </div>
                <h3 className="mt-4 font-serif text-xl font-medium text-card-foreground">
                  Thank you for reaching out
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  {"We'll get back to you within 24 hours."}
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-6 text-sm font-medium text-accent hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="rounded-2xl border border-border bg-card p-8 md:p-10"
              >
                <div className="grid gap-5 md:grid-cols-2">
                  <div>
                    <label htmlFor="firstName" className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      First Name
                    </label>
                    <input
                      id="firstName"
                      name="firstName"
                      type="text"
                      required
                      className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-accent focus:ring-1 focus:ring-accent focus:outline-none"
                      placeholder="Your first name"
                    />
                  </div>
                  <div>
                    <label htmlFor="lastName" className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Last Name
                    </label>
                    <input
                      id="lastName"
                      name="lastName"
                      type="text"
                      required
                      className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-accent focus:ring-1 focus:ring-accent focus:outline-none"
                      placeholder="Your last name"
                    />
                  </div>
                </div>

                <div className="mt-5">
                  <label htmlFor="email" className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-accent focus:ring-1 focus:ring-accent focus:outline-none"
                    placeholder="you@hotel.com"
                  />
                </div>

                <div className="mt-5 grid gap-5 md:grid-cols-2">
                  <div>
                    <label htmlFor="organisation" className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Organisation
                    </label>
                    <input
                      id="organisation"
                      name="organisation"
                      type="text"
                      className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-accent focus:ring-1 focus:ring-accent focus:outline-none"
                      placeholder="Hotel or company name"
                    />
                  </div>
                  <div>
                    <label htmlFor="role" className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Role
                    </label>
                    <input
                      id="role"
                      name="role"
                      type="text"
                      className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-accent focus:ring-1 focus:ring-accent focus:outline-none"
                      placeholder="Your role"
                    />
                  </div>
                </div>

                <div className="mt-5">
                  <label htmlFor="message" className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={4}
                    className="w-full resize-none rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-accent focus:ring-1 focus:ring-accent focus:outline-none"
                    placeholder="Tell us about your property and sustainability goals..."
                  />
                </div>

                <button
                  type="submit"
                  className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-accent px-7 py-3 text-sm font-semibold text-accent-foreground transition-opacity hover:opacity-90 md:w-auto"
                >
                  <Send className="h-4 w-4" />
                  Submit
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
