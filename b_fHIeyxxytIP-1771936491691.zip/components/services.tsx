import Image from "next/image"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

const services = [
  {
    number: "01",
    title: "Food Waste Reduction",
    description:
      "We audit hotel kitchens and buffet operations to identify waste sources, then design bespoke reduction strategies — from composting programmes and smart portioning to local supplier partnerships that close the loop on organic waste.",
    image: "/images/service-food.jpg",
    alt: "Hotel chef implementing sustainable food practices in kitchen",
    features: ["Kitchen audits", "Composting systems", "Supplier mapping", "Menu optimisation"],
  },
  {
    number: "02",
    title: "Energy Optimisation",
    description:
      "Our energy consultants assess building performance, HVAC systems, and lighting infrastructure to deliver measurable savings. We help hotels transition to renewable sources and implement smart monitoring for continuous improvement.",
    image: "/images/service-energy.jpg",
    alt: "Solar panels on a modern hotel rooftop in Mediterranean setting",
    features: ["Energy audits", "Solar integration", "Smart monitoring", "Carbon reporting"],
  },
  {
    number: "03",
    title: "Sustainability Training",
    description:
      "Lasting change requires a cultural shift. Our training programmes equip hotel staff at every level with the knowledge and motivation to embed sustainable practices into daily operations — from housekeeping to management.",
    image: "/images/service-training.jpg",
    alt: "Hotel staff attending a sustainability training workshop",
    features: ["Staff workshops", "Leadership coaching", "Certification prep", "Ongoing support"],
  },
]

export function Services() {
  return (
    <section id="services" className="bg-primary py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        {/* Header */}
        <p className="text-sm font-medium uppercase tracking-[0.2em] text-primary-foreground/60">
          Our Services
        </p>
        <h2 className="mt-4 max-w-2xl text-balance font-serif text-3xl font-medium leading-snug text-primary-foreground md:text-4xl">
          A Holistic Approach to Sustainable Hospitality
        </h2>

        {/* Service Cards */}
        <div className="mt-16 flex flex-col gap-20">
          {services.map((service, index) => (
            <div
              key={service.number}
              className={`grid items-center gap-10 lg:grid-cols-2 lg:gap-16 ${
                index % 2 === 1 ? "lg:direction-rtl" : ""
              }`}
            >
              {/* Image */}
              <div className={`relative overflow-hidden rounded-2xl ${index % 2 === 1 ? "lg:order-2" : ""}`}>
                <Image
                  src={service.image}
                  alt={service.alt}
                  width={800}
                  height={600}
                  className="aspect-[4/3] w-full object-cover transition-transform duration-500 hover:scale-105"
                />
                {/* Number badge */}
                <div className="absolute top-4 left-4 flex h-10 w-10 items-center justify-center rounded-full bg-accent text-sm font-bold text-accent-foreground">
                  {service.number}
                </div>
              </div>

              {/* Content */}
              <div className={index % 2 === 1 ? "lg:order-1" : ""}>
                <h3 className="font-serif text-2xl font-medium text-primary-foreground md:text-3xl">
                  {service.title}
                </h3>
                <p className="mt-4 text-pretty leading-relaxed text-primary-foreground/70">
                  {service.description}
                </p>

                {/* Feature tags */}
                <div className="mt-6 flex flex-wrap gap-2">
                  {service.features.map((feature) => (
                    <span
                      key={feature}
                      className="rounded-full border border-primary-foreground/20 px-3 py-1 text-xs font-medium text-primary-foreground/80"
                    >
                      {feature}
                    </span>
                  ))}
                </div>

                <Link
                  href="#contact"
                  className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-accent transition-colors hover:text-accent/80"
                >
                  Learn more <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
