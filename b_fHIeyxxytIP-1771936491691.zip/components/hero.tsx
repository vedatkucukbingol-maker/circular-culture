import Image from "next/image"
import Link from "next/link"
import { ArrowDown } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-end pb-20 pt-32 overflow-hidden">
      {/* Background Image */}
      <Image
        src="/images/hero-antalya.jpg"
        alt="Aerial view of sustainable hotel on the Antalya coast"
        fill
        className="object-cover"
        priority
      />

      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#1a2e20]/90 via-[#1a2e20]/40 to-[#1a2e20]/20" />

      {/* Content */}
      <div className="relative z-10 mx-auto w-full max-w-6xl px-6">
        <p className="mb-4 text-sm font-medium uppercase tracking-[0.2em] text-[#a8d5ba]">
          Sustainable Tourism Consultancy
        </p>
        <h1 className="max-w-3xl text-balance font-serif text-4xl font-medium leading-tight text-[#f5f0e8] md:text-6xl lg:text-7xl">
          Redefining Hospitality for a Circular Future
        </h1>
        <p className="mt-6 max-w-xl text-pretty text-base leading-relaxed text-[#d4cfc5] md:text-lg">
          We partner with hotels across the Turkish Riviera to reduce waste, optimise energy, and build lasting sustainability cultures.
        </p>

        <div className="mt-10 flex flex-wrap items-center gap-4">
          <Link
            href="#services"
            className="inline-flex items-center justify-center rounded-full bg-accent px-7 py-3 text-sm font-semibold text-accent-foreground transition-opacity hover:opacity-90"
          >
            Our Services
          </Link>
          <Link
            href="#contact"
            className="inline-flex items-center justify-center rounded-full border border-[#f5f0e8]/30 px-7 py-3 text-sm font-semibold text-[#f5f0e8] transition-colors hover:bg-[#f5f0e8]/10"
          >
            Start a Conversation
          </Link>
        </div>

        {/* Scroll indicator */}
        <div className="mt-16 flex items-center gap-2 text-[#a8d5ba]">
          <ArrowDown className="h-4 w-4 animate-bounce" />
          <span className="text-xs uppercase tracking-widest">Scroll to explore</span>
        </div>
      </div>
    </section>
  )
}
